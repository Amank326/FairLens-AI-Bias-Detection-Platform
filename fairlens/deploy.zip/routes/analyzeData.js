const express = require('express');
const router = express.Router();
const { analyzeDatasetWithGemini } = require('../services/geminiService');

/**
 * @route POST /analyze
 * @description Analyzes a dataset summary for bias using Google Gemini
 */
router.post('/analyze', async (req, res) => {
  try {
    const { datasetSummary, metrics } = req.body;

    // 1. Validation Error Handling
    if (!datasetSummary || !metrics) {
      return res.status(400).json({ error: "Missing datasetSummary or metrics in request payload." });
    }

    // 2. Call the newly architected Gemini Service
    const aiResult = await analyzeDatasetWithGemini(datasetSummary, metrics);

    // 3. Return JSON response
    return res.status(200).json(aiResult);

  } catch (error) {
    console.error("Gemini API / Route Error:", error.message);
    // Explicit Error Handling: Check if API key is missing
    if (error.message.includes('GEMINI_API_KEY')) {
      return res.status(500).json({ error: "Ensure backend connection is running with the GEMINI_API_KEY set." });
    }
    
    return res.status(500).json({ error: error.message || "Analysis failed due to internal server error." });
  }
});

module.exports = router;